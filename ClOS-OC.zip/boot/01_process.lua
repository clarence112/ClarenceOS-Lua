-- Initialize process module.
require("process").install("/init.lua", "init")
