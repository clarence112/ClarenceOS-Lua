os = require("os")
io = require("io")
computer = require("computer")

computer.beep(300)
computer.beep(600)
computer.beep(400)

function currentDir()
  local files = {}
  local tmpfile = '/clos/stmp.txt'
  os.execute('pwd  > /clos/stmp.txt')
  local f = io.open(tmpfile)
  if not f then
    return files
  end
  local k = 1
  for line in f:lines() do
    files[k] = line
    k = k + 1
  end
  f:close()
  return files[1]
end

test = currentDir()
print(test)

computer.beep(600)
computer.beep(400)
computer.beep(300)